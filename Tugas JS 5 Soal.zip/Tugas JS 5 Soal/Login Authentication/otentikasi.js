const username = document.querySelector(".user");
const password = document.querySelector(".pass");
const button = document.querySelector(".btn");

button.addEventListener("click", () => {
  if (username.value == "ahmad2021" && password.value == "novelty") {
    alert("Login Sucess")
  } else if (username.value != "tirtaraja" && password.value == "STTNURULFIKRI") {
    alert("Username atau password salah")
  } else if (username.value == "tirtaraja" && password.value != "STTNURULFIKRI") {
    alert("Username atau password salah")
  } else {
    alert(`Belum punya akun ?`);
  }
})
